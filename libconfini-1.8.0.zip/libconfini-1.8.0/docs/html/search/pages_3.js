var searchData=
[
  ['rationale',['Rationale',['../rationale.html',1,'']]],
  ['readme',['README',['../readme.html',1,'']]]
];
