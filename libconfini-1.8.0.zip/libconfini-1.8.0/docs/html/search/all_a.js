var searchData=
[
  ['no_5fdouble_5fquotes',['no_double_quotes',['../structIniFormat.html#aa6e8b4274f3da1468a1806398b504d64',1,'IniFormat']]],
  ['no_5fsingle_5fquotes',['no_single_quotes',['../structIniFormat.html#a2fe0e57e8a802f828bc12a6462438e38',1,'IniFormat']]],
  ['no_5fspaces_5fin_5fnames',['no_spaces_in_names',['../structIniFormat.html#a491e94bda3f8545471a86f0845c92474',1,'IniFormat']]]
];
