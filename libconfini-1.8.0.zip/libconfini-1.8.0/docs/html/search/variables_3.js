var searchData=
[
  ['d_5flen',['d_len',['../structIniDispatch.html#a34937218fa772fa66ceaa38923437791',1,'IniDispatch']]],
  ['data',['data',['../structIniDispatch.html#a3821b15b23e587eca172763dd4acd954',1,'IniDispatch']]],
  ['delimiter_5fsymbol',['delimiter_symbol',['../structIniFormat.html#a6d9981301f5a16d73e2c38cb80f7f962',1,'IniFormat']]],
  ['disabled_5fafter_5fspace',['disabled_after_space',['../structIniFormat.html#a6ad00ea76bbe5ed109f4192f89859656',1,'IniFormat']]],
  ['disabled_5fcan_5fbe_5fimplicit',['disabled_can_be_implicit',['../structIniFormat.html#ab5937aaf72b0ce5b62aece8d23ad7b82',1,'IniFormat']]],
  ['dispatch_5fid',['dispatch_id',['../structIniDispatch.html#a795864cff55f67498aa22722c17fc6d2',1,'IniDispatch']]],
  ['do_5fnot_5fcollapse_5fvalues',['do_not_collapse_values',['../structIniFormat.html#af411935de86436fb9555ee57ba04960e',1,'IniFormat']]]
];
