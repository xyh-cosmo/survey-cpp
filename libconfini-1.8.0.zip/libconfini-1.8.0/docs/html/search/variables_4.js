var searchData=
[
  ['format',['format',['../structIniStatistics.html#a1432aac124e3bc81c6845b42c16ef732',1,'IniStatistics::format()'],['../structIniDispatch.html#adfda221d4a9effcb4f3ee6a99c5f2de2',1,'IniDispatch::format()']]]
];
