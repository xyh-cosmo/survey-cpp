var searchData=
[
  ['rationale',['Rationale',['../rationale.html',1,'']]],
  ['rationale_2emd',['RATIONALE.md',['../RATIONALE_8md.html',1,'']]],
  ['readme',['README',['../readme.html',1,'']]],
  ['readme_2emd',['README.md',['../README_8md.html',1,'']]],
  ['rtrim_5fh',['rtrim_h',['../confini_8c.html#a0b1869614c299f77292827e725c43dd2',1,'confini.c']]],
  ['rtrim_5fs',['rtrim_s',['../confini_8c.html#a7dfbd0c5cf4d6a75ce90028ea1ddd7a3',1,'confini.c']]]
];
