var searchData=
[
  ['load_5fini_5ffile',['load_ini_file',['../confini_8c.html#a7d5042d3044dfb5a34a6bfc5af3a882d',1,'load_ini_file(FILE *const ini_file, const IniFormat format, const IniStatsHandler f_init, const IniDispHandler f_foreach, void *const user_data):&#160;confini.c'],['../confini_8h.html#a7d5042d3044dfb5a34a6bfc5af3a882d',1,'load_ini_file(FILE *const ini_file, const IniFormat format, const IniStatsHandler f_init, const IniDispHandler f_foreach, void *const user_data):&#160;confini.c']]],
  ['load_5fini_5fpath',['load_ini_path',['../confini_8c.html#a54be108d26619db3066ce1c000dc8a17',1,'load_ini_path(const char *const path, const IniFormat format, const IniStatsHandler f_init, const IniDispHandler f_foreach, void *const user_data):&#160;confini.c'],['../confini_8h.html#a54be108d26619db3066ce1c000dc8a17',1,'load_ini_path(const char *const path, const IniFormat format, const IniStatsHandler f_init, const IniDispHandler f_foreach, void *const user_data):&#160;confini.c']]],
  ['ltrim_5fh',['ltrim_h',['../confini_8c.html#a650bc67f1b3a687315da0819f6c0d4e8',1,'confini.c']]],
  ['ltrim_5fhh',['ltrim_hh',['../confini_8c.html#a1ff7eb44c763366d9c1c0e7ef435ad3a',1,'confini.c']]],
  ['ltrim_5fs',['ltrim_s',['../confini_8c.html#a84cb708a44e66d0c178f096a582f40f9',1,'confini.c']]]
];
