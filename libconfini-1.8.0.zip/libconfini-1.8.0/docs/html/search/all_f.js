var searchData=
[
  ['type',['type',['../structIniDispatch.html#a7f6ebc6713aae413c4157ce68008a8a8',1,'IniDispatch']]]
];
