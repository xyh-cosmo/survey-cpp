var searchData=
[
  ['case_5fsensitive',['case_sensitive',['../structIniFormat.html#a50f562eda0d26ed7e0d3c57afeb46d2d',1,'IniFormat']]]
];
