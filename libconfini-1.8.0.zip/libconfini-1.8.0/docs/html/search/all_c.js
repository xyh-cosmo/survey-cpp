var searchData=
[
  ['qultrim_5fh',['qultrim_h',['../confini_8c.html#a43eebf8c2f153dcaaf7db2d590f1d8cd',1,'confini.c']]]
];
