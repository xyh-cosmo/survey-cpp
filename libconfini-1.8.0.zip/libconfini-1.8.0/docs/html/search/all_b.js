var searchData=
[
  ['preserve_5fempty_5fquotes',['preserve_empty_quotes',['../structIniFormat.html#ad224b6997bbb99d4715fba8a8bea4cd7',1,'IniFormat']]]
];
