var searchData=
[
  ['sanitize_5fsection_5fpath',['sanitize_section_path',['../confini_8c.html#aa17889754780149f18e417607e5ffb24',1,'confini.c']]],
  ['section_5fpaths',['section_paths',['../structIniFormat.html#a3168fd8d019de9a2f648a1805718b310',1,'IniFormat']]],
  ['semicolon_5fmarker',['semicolon_marker',['../structIniFormat.html#aab0c2bf1e89593bbbfc9ac5fc5f6f552',1,'IniFormat']]],
  ['string_5ftolower',['string_tolower',['../confini_8c.html#ad6e6972b13052e995b3ceb2fb4996ede',1,'confini.c']]]
];
