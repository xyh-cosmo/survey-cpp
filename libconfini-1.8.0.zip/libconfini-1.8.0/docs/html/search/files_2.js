var searchData=
[
  ['manual_2emd',['MANUAL.md',['../MANUAL_8md.html',1,'']]]
];
