var searchData=
[
  ['section_5fpaths',['section_paths',['../structIniFormat.html#a3168fd8d019de9a2f648a1805718b310',1,'IniFormat']]],
  ['semicolon_5fmarker',['semicolon_marker',['../structIniFormat.html#aab0c2bf1e89593bbbfc9ac5fc5f6f552',1,'IniFormat']]]
];
