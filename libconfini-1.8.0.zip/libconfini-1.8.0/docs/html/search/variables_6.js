var searchData=
[
  ['implicit_5fis_5fnot_5fempty',['implicit_is_not_empty',['../structIniFormat.html#ae5722efd535f1d27c624a927eea622c3',1,'IniFormat']]],
  ['ini_5fbooleans',['INI_BOOLEANS',['../confini_8c.html#afdb9fd02d693536253da07f0f468aaef',1,'confini.c']]],
  ['ini_5fdefault_5fformat',['INI_DEFAULT_FORMAT',['../confini_8h.html#aafa50d590c715f37b74fa5938a35a56f',1,'confini.h']]],
  ['ini_5fget_5ffloat',['ini_get_float',['../confini_8c.html#a26dd8ef0bfb57aaedbeac8007fd1a03a',1,'ini_get_float():&#160;confini.c'],['../confini_8h.html#a178704d02ede6101f757bbd37e5bd697',1,'ini_get_float():&#160;confini.c']]],
  ['ini_5fget_5fint',['ini_get_int',['../confini_8c.html#adba0d5ee273d05ed845c66f01a621119',1,'ini_get_int():&#160;confini.c'],['../confini_8h.html#a5b6bebfc01f8b23f69a2a2e602e91521',1,'ini_get_int():&#160;confini.c']]],
  ['ini_5fget_5flint',['ini_get_lint',['../confini_8c.html#ae334387b2202eca25e16fb92694d56ca',1,'ini_get_lint():&#160;confini.c'],['../confini_8h.html#a05042d2551ab1c9402ab7223547c0777',1,'ini_get_lint():&#160;confini.c']]],
  ['ini_5fget_5fllint',['ini_get_llint',['../confini_8c.html#a9562da3c55b51795bbcbb2b19d608907',1,'ini_get_llint():&#160;confini.c'],['../confini_8h.html#aaf3640e3632b10bf8dd2e852a7d82630',1,'ini_get_llint():&#160;confini.c']]],
  ['ini_5fglobal_5fimplicit_5fv_5flen',['INI_GLOBAL_IMPLICIT_V_LEN',['../confini_8c.html#acecf086ca074b27365e877f056af2192',1,'INI_GLOBAL_IMPLICIT_V_LEN():&#160;confini.c'],['../confini_8h.html#acecf086ca074b27365e877f056af2192',1,'INI_GLOBAL_IMPLICIT_V_LEN():&#160;confini.c']]],
  ['ini_5fglobal_5fimplicit_5fvalue',['INI_GLOBAL_IMPLICIT_VALUE',['../confini_8c.html#a243b229193f154746a9fbfbdb02689bf',1,'INI_GLOBAL_IMPLICIT_VALUE():&#160;confini.c'],['../confini_8h.html#a243b229193f154746a9fbfbdb02689bf',1,'INI_GLOBAL_IMPLICIT_VALUE():&#160;confini.c']]],
  ['ini_5fglobal_5flowercase_5fmode',['INI_GLOBAL_LOWERCASE_MODE',['../confini_8c.html#af55e2631f0e3f941175a9b406b66ab06',1,'INI_GLOBAL_LOWERCASE_MODE():&#160;confini.c'],['../confini_8h.html#af55e2631f0e3f941175a9b406b66ab06',1,'INI_GLOBAL_LOWERCASE_MODE():&#160;confini.c']]],
  ['ini_5funixlike_5fformat',['INI_UNIXLIKE_FORMAT',['../confini_8h.html#a724e3c7be7055b35bccb080f748868b5',1,'confini.h']]]
];
