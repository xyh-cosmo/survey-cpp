var searchData=
[
  ['inidispatch',['IniDispatch',['../structIniDispatch.html',1,'']]],
  ['iniformat',['IniFormat',['../structIniFormat.html',1,'']]],
  ['inistatistics',['IniStatistics',['../structIniStatistics.html',1,'']]]
];
