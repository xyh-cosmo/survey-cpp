var searchData=
[
  ['inicommentmarker',['IniCommentMarker',['../confini_8h.html#a6f7ff029dfae5a0e3bb5bc08f887bdcd',1,'confini.h']]],
  ['inidelimiters',['IniDelimiters',['../confini_8h.html#ad342637c37d95454c9392a8cc73bced8',1,'confini.h']]],
  ['inimultiline',['IniMultiline',['../confini_8h.html#ac670c2fdf19ae6eee3de83dd183ae55f',1,'confini.h']]],
  ['ininodetype',['IniNodeType',['../confini_8h.html#a4e394db479f56eaa830ade09c907461b',1,'confini.h']]],
  ['inisectionpaths',['IniSectionPaths',['../confini_8h.html#a4b01f84229fe403d5b061378ebe86134',1,'confini.h']]]
];
