var searchData=
[
  ['confini_5ferror',['CONFINI_ERROR',['../confini_8h.html#a0b9dcb5c0711475ea78b065b0322bde1',1,'confini.h']]]
];
