var searchData=
[
  ['rationale_2emd',['RATIONALE.md',['../RATIONALE_8md.html',1,'']]],
  ['readme_2emd',['README.md',['../README_8md.html',1,'']]]
];
