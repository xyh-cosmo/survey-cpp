var searchData=
[
  ['confini_5feio',['CONFINI_EIO',['../confini_8h.html#a4b42cb63e48154fb799599eccd25ce29a8b9b6ea5c455bfad3976fd394c36a91d',1,'confini.h']]],
  ['confini_5fenoent',['CONFINI_ENOENT',['../confini_8h.html#a4b42cb63e48154fb799599eccd25ce29aca147c275760856386fdb9e778525676',1,'confini.h']]],
  ['confini_5fenomem',['CONFINI_ENOMEM',['../confini_8h.html#a4b42cb63e48154fb799599eccd25ce29a0e8e1cee80bc4b7839838764f5d661f5',1,'confini.h']]],
  ['confini_5feoor',['CONFINI_EOOR',['../confini_8h.html#a4b42cb63e48154fb799599eccd25ce29a82e26058d2b7bb2203fe321d0320d98a',1,'confini.h']]],
  ['confini_5ffeintr',['CONFINI_FEINTR',['../confini_8h.html#a4b42cb63e48154fb799599eccd25ce29a133a335ff201d93015a27bd581e6b399',1,'confini.h']]],
  ['confini_5fiintr',['CONFINI_IINTR',['../confini_8h.html#a4b42cb63e48154fb799599eccd25ce29a1435b36fb0e428e18c5f6a32408eb3ea',1,'confini.h']]],
  ['confini_5fsuccess',['CONFINI_SUCCESS',['../confini_8h.html#a4b42cb63e48154fb799599eccd25ce29ab6180fd6db09408e11eb1c27fb7028e7',1,'confini.h']]]
];
