var searchData=
[
  ['sanitize_5fsection_5fpath',['sanitize_section_path',['../confini_8c.html#aa17889754780149f18e417607e5ffb24',1,'confini.c']]],
  ['string_5ftolower',['string_tolower',['../confini_8c.html#ad6e6972b13052e995b3ceb2fb4996ede',1,'confini.c']]]
];
