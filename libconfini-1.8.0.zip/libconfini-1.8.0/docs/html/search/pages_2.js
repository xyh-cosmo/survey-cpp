var searchData=
[
  ['libconfini',['libconfini',['../index.html',1,'']]],
  ['library_20functions_20manual',['Library Functions Manual',['../libconfini.html',1,'']]]
];
