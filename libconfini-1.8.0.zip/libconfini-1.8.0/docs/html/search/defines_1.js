var searchData=
[
  ['iniformat_5fhas_5fno_5fesc',['INIFORMAT_HAS_NO_ESC',['../confini_8h.html#a3b5912b45e4def482018fa44ad99ffb0',1,'confini.h']]],
  ['iniformat_5ftable_5fas',['INIFORMAT_TABLE_AS',['../confini_8h.html#ab2c2bb06f2e04cde2b010c360c431a12',1,'confini.h']]]
];
