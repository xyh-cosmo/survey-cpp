var searchData=
[
  ['collapse_5fempty_5fquotes',['collapse_empty_quotes',['../confini_8c.html#a6dfd90309965c426ac9b072d79a08601',1,'confini.c']]],
  ['collapse_5feverything',['collapse_everything',['../confini_8c.html#a4f8808c57ddfc07ba7b55370ff34f5cb',1,'confini.c']]],
  ['collapse_5fspaces',['collapse_spaces',['../confini_8c.html#ab63671eba263728ddc8ad7dda7568172',1,'confini.c']]]
];
