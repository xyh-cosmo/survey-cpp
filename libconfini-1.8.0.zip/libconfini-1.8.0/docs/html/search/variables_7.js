var searchData=
[
  ['members',['members',['../structIniStatistics.html#ab4af1f388bd4109a9a9b1bc449146ec7',1,'IniStatistics']]],
  ['multiline_5fnodes',['multiline_nodes',['../structIniFormat.html#a8a4a1d116d66bad0c61d9876bf9f87ee',1,'IniFormat']]]
];
